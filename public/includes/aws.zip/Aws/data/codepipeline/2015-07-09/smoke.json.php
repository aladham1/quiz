<?php
// This file was auto-generated from sdk-root/src/data/codepipeline/2015-07-09/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListPipelines', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'GetPipeline', 'input' => [ 'name' => 'fake-pipeline', ], 'errorExpectedFromService' => true, ], ],];
