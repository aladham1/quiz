<?php
// This file was auto-generated from sdk-root/src/data/translate/2017-07-01/paginators-1.json
return [ 'pagination' => [ 'ListTerminologies' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', ], 'ListTextTranslationJobs' => [ 'input_token' => 'NextToken', 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', ], ],];
