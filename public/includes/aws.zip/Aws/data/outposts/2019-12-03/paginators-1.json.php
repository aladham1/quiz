<?php
// This file was auto-generated from sdk-root/src/data/outposts/2019-12-03/paginators-1.json
return [ 'pagination' => [ 'ListOutposts' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'ListSites' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
